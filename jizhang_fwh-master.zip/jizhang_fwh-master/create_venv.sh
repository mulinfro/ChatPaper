#!/bin/bash
CURRENT_DIR=$(cd `dirname $0`; pwd)

python3.10 -m venv /home/ubuntu/python_venv/qa-client
source /home/ubuntu/python_venv/qa-client/bin/activate

cd $CURRENT_DIR
pip3.10 install -r ./requirements.txt

deactivate