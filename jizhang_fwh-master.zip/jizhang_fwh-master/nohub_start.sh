#!/bin/bash

# CURRENT_DIR=$(cd `dirname $0`; pwd)
nohup ./start.sh >> ./runoob.log 2>&1 &
