#!/bin/bash

source /home/ubuntu/python_venv/qa-client/bin/activate
export API_KEY=""

uvicorn main:app --host '0.0.0.0' --port 8080 #--reload
