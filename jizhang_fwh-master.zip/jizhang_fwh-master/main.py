from fastapi import FastAPI
from app.routers import query
import os

# 测试时才打开docs, 上线关闭
env = os.getenv('env')
if env == 'develop':
    app = FastAPI(docs_url="/1q2w3e4r-docs", redoc_url="/1q2w3e4r-redocs")
else:
    app = FastAPI(docs_url=None, redoc_url=None)

# 增加path复杂性避免被扫描
root_path = "/s5twxok9"
app.include_router(query.router, prefix=root_path)


@app.on_event("startup")
def startup():
    pass

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, port=8080)
