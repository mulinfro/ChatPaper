from enum import Enum
from datetime import date
from typing import Dict, Optional

from pydantic import BaseModel


from typing import List


class MsgType(str, Enum):
    text = "text"
    image = "image"
    voice = "voice"
    video = "video"
    event = "event"


class WeChatMessage(BaseModel):
    ToUserName: str
    FromUserName: str
    CreateTime: int
    MsgType: MsgType
    Content: Optional[str] = None  # text
    PicUrl: Optional[str] = None   # pic
    MediaId: Optional[str] = None
    Format: Optional[str] = None
    ThumbMediaId: Optional[str] = None
    Event: Optional[str] = None  # event
    EventKey: Optional[str] = None
    MsgId: Optional[int] = None



class ProductDetail(BaseModel):
    product_id: int
    quantity: int
    price: float

class TradeAction(str, Enum):
    buy = 'buy'
    sell = 'sell'

class StockRecordCreate(BaseModel):
    date: date
    user_id: int
    action: TradeAction
    products: List[ProductDetail]