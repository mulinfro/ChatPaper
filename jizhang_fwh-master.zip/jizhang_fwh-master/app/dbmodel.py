from sqlalchemy import create_engine, Column, Integer, String, Float, Date, ForeignKey, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship, sessionmaker

# 初始化数据库
DATABASE_URL = "postgresql://user:password@localhost/dbname"
engine = create_engine(DATABASE_URL, echo=True)

Base = declarative_base()


# 用户类
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True)


class StockRecord(Base):
    __tablename__ = "stocks"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, nullable=False)
    product_name = Column(String, nullable=False)
    # buy > 0; sell < 0
    quantity = Column(Integer, nullable=False)
    price = Column(Float, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))


# 商品类
class Products(Base):
    __tablename__ = "products"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"))
    default_cost = Column(Float, nullable=False, default=-1)
    default_price = Column(Float, nullable=False, default=-1)


# 库存利润类
class InventoryProfit(Base):
    __tablename__ = "inventory_profits"

    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, nullable=False)
    product_id = Column(Integer, ForeignKey("products.id"))
    user_id = Column(Integer, ForeignKey("users.id"))
    inventory = Column(Integer, nullable=False)
    sales = Column(Float, nullable=False)
    profit = Column(Float, nullable=False)
    inventory_detail = Column(JSON, nullable=False)  # 添加新字段

    #product = relationship("Product", back_populates="inventory_profits")
    #user = relationship("User", back_populates="inventory_profits")	


Base.metadata.create_all(bind=engine)

# 创建会话工厂
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# 依赖关系
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()