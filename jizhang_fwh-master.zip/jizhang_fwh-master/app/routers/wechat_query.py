from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
import datetime
from ..schemas import StockRecordCreate, WeChatMessage, MsgType
from ..dbmodel import get_db, Product, StockRecord, InventoryProfit


router = APIRouter(
    prefix="/query",
    tags=["query"],
    # dependencies=[Depends(get_token_header)],
    responses={404: {"description": "Not found"}},
)


def float_to_str_key(value, precision=2):
    return f"{round(value, precision):.0{precision}f}"


# 获取当前库存利润记录或创建新记录
def get_or_create_inventory_profit(db: Session, date: datetime.date, user_id: int, product_id: int):
    inventory_profit = db.query(InventoryProfit).filter(InventoryProfit.date == date,
                                                        InventoryProfit.user_id == user_id,
                                                        InventoryProfit.product_id == product_id).first()
    if not inventory_profit:
        latest_inventory_profit = db.query(InventoryProfit).filter(InventoryProfit.user_id == user_id,
                                    InventoryProfit.product_id == product_id).order_by(
                                    InventoryProfit.date.desc()).first()
        
        inventory = latest_inventory_profit.inventory if latest_inventory_profit else 0
        inventory_detail = latest_inventory_profit.inventory_detail  if latest_inventory_profit else {}
        inventory_profit = InventoryProfit(date=date,
                                        user_id=user_id,
                                        product_id=product_id,
                                        inventory=inventory,
                                        inventory_detail=inventory_detail,
                                        sales=0,
                                        profit=0)
        db.add(inventory_profit)
        db.commit()
        db.refresh(inventory_profit)
    return inventory_profit


def stock_in_update_inventory(db, stock_in_record):
    inventory_profit = get_or_create_inventory_profit(db, stock_in_record.date,stock_in_record.user_id, stock_in_record.product_id)
    if inventory_profit:
        inventory_profit.inventory += stock_in_record.quantity
        # 更新库存详细信息
        inventory_detail = inventory_profit.inventory_detail
        cost = str(stock_in_record.cost)
        if  cost in inventory_detail:
            inventory_detail[cost] += stock_in_record.quantity
        else:
            inventory_detail[cost] = stock_in_record.quantity
        inventory_profit.inventory_detail = inventory_detail

    db.commit()

def stock_out_update_inventory(db, stock_out_record):
    inventory_profit = get_or_create_inventory_profit(db, stock_out_record.date, stock_out_record.user_id, stock_out_record.product_id)

    if inventory_profit and inventory_profit.inventory >= stock_out_record.quantity:
        inventory_profit.inventory -= stock_out_record.quantity
        sales = stock_out_record.price * stock_out_record.quantity
        inventory_profit.sales += sales
        # 更新利润和库存详细信息
        inventory_detail = inventory_profit.inventory_detail
        cost = 0
        quantity = stock_out_record.quantity
        for key in inventory_detail:
            if inventory_detail[key] >= quantity:
                inventory_detail[key] -= quantity
                cost += float(key) * quantity
                quantity = 0
                break
            else:
                quantity -= inventory_detail[key]
                cost += float(key) * inventory_detail[key]
                inventory_detail.pop(key)

        inventory_profit.profit += (sales - cost) 
        inventory_profit.inventory_detail = inventory_detail

        db.commit()
    else:
        raise HTTPException(status_code=400, detail="存库不足销量")


# 入库操作
@router.post("/stock_in/")
def stock_in(stock_in_records: StockInRecordCreate, db: Session = Depends(get_db)):
    for stock_in_record in stock_in_records:
        product = db.query(Product).filter(Product.name == stock_in_record.product_name).first()
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")

        stock_in = StockInRecord(date=stock_in_record.date,
                                product_name=stock_in_record.product_name,
                                quantity=stock_in_record.quantity,
                                cost=stock_in_record.cost or product.default_cost,
                                user_id=stock_in_record.user_id)
        db.add(stock_in)
        db.commit()

        stock_in_update_inventory(db, stock_in_record)
    return {"code": 0, "message": "Stock in records added successfully"}

# 出库操作
@router.post("/stock_out/")
def stock_out(stock_out_records: StockOutRecordCreate, db: Session = Depends(get_db)):
    for stock_out_record in stock_out_records:
        product = db.query(Product).filter(Product.name == stock_out_record.product_name).first()
        if not product:
            raise HTTPException(status_code=404, detail="Product not found")

        stock_out = StockOutRecord(date=stock_out_record.date,
                                product_name=stock_out_record.product_name,
                                quantity=stock_out_record.quantity,
                                price=stock_out_record.price or product.default_price,
                                user_id=stock_out_record.user_id)
        db.add(stock_out)
        db.commit()

        stock_out_update_inventory(db, stock_out_record.date, stock_out_record.user_id, stock_out_record.product_id)
    return {"code": 0, "message": "Stock out records added successfully"}


"""
{
  "date": "2024-06-10",
  "user_id": 123,
  "action": "buy",
  "products": [
    {
      "product_id": 1,
      "quantity": 10,
      "price": 100.0
    },
    {
      "product_id": 2,
      "quantity": 5,
      "price": 200.0
    }
  ]
}
"""

"""
{
  "touser": "USER_OPENID",
  "msgtype": "text",
  "text": {
    "content": "您的交易记录：\n日期: 2024-06-10\n用户ID: 123\n动作: 买入\n产品: \n  - 产品ID: 1, 数量: 10, 价格: 100.0\n  - 产品ID: 2, 数量: 5, 价格: 200.0"
  }
}
"""

@router.post("/stock_act/")
def stock_in(stock_records: StockRecordCreate, db: Session = Depends(get_db)):



@router.get("/inventory_profits/{user_id}/{start_date}/{end_date}")
def get_inventory_profits(user_id: int, start_date: datetime.date, end_date: datetime.date, db: Session = Depends(get_db)):
    inventory_profits = db.query(InventoryProfit).filter(InventoryProfit.user_id == user_id,
                            InventoryProfit.date.between(start_date, end_date)).order_by(
                            InventoryProfit.date).all()
    return inventory_profits


from s

@router.post("/wechat/message")
async def handle_wechat_message(message: WeChatMessage):
    if message.MsgType == MsgType.text:
        return {"response": f"Received text message: {message.Content}"}
    elif message.MsgType == MsgType.image:
        return {"response": f"Received image message with URL: {message.PicUrl} and MediaId: {message.MediaId}"}
    elif message.MsgType == MsgType.voice:
        return {"response": f"Received voice message with MediaId: {message.MediaId} and Format: {message.Format}"}
    elif message.MsgType == MsgType.video:
        return {"response": f"Received video message with MediaId: {message.MediaId} and ThumbMediaId: {message.ThumbMediaId}"}
    elif message.MsgType == MsgType.event:
        return {"response": f"Received event: {message.Event} with EventKey: {message.EventKey}"}
    else:
        return {"response": "Unknown message type"}