
from ..schemas import StockRecordCreate
from utils.qianwen import call_with_messages
import json

from .intent import *

def call_one_shot(prompt):
    messages = [{'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': prompt}]
    return call_with_messages(messages)

def parse_intent(content):
    prompt = intent_prompt % content
    res = call_one_shot(prompt)
    if res in [IN_QUERY, IN_STOCK]:
        return res
    else:
        return IN_UNK
        
def parse_stock_data(content):
    prompt = stock_prompt % content
    res = call_one_shot(prompt)
    try:
        # 尝试解析 JSON 字符串
        data = json.loads(res)
        return data
    except Exception as e:
        # 捕获所有其他异常
        print(f"Unexpected error: {e}")
        return None

def parse_data_query(content):
    pass


def parse_query(content):
    intent = parse_intent(content)
    if intent == IN_STOCK:
        data = parse_stock_data(content)
        stock_act(data)
    elif intent == IN_QUERY:
        pass
    elif intent == IN_UNK:
        pass