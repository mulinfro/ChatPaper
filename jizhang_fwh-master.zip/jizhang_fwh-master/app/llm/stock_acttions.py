

from ..schemas import StockRecordCreate


def stock_act(stock_records: StockRecordCreate, db):