
system_prompt = "你是一个库存管理对话机器人。"


IN_STOCK = "入库出库" 
IN_QUERY = "数据查询"
IN_UNK = "未知"

intent_prompt = """你是一个库存管理对话机器人。
有两个任务：1. 入库出库， 2.数据查询

请识别如下文本的意图：
```%s```

直接返回对应的意图; 如果不在这两个意图里，返回未知
"""


stock_prompt = """
你是一个库存管理对话机器人，需要从文本中提取出入库出库的数据。

例子如下：
输入： 我刚买了30斤香蕉，每斤2.5元，20斤橙子，单价4元。
返回json格式
{
  "action": "buy",
  "products": [
    {
      "name": 1,
      "quantity": 10,
      "price": 100.0
    },
    {
      "name": 2,
      "quantity": 5,
      "price": 200.0
    }
  ]
}

action有两个取值： buy, sell
"""


data_query_prompt = """


"""